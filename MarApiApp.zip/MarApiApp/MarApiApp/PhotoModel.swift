//
//  PhotoModel.swift
//  MarApiApp
//
//  Created by iMac on 03/02/23.
//

import UIKit

import Foundation

struct PhotoModel: Codable {
    
    var photos: [Photos]?
    
    struct Photos: Codable {
        var img_src: String?
        var rover: Rover?
        var sol: Int?
        var earthDate: String?
        var camera: Camera?
        var id: Int?
    }
    
    struct Rover: Codable {
        var name: String?
        var status: String?
        var id: Int?
        var landingDate: String?
        var launchDate: String?
    }
    
    struct Camera: Codable {
        var name: String?
        var id: Int?
        var roverId: Int?
        var fullName: String?
    }
}
