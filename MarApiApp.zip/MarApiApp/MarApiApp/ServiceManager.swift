//
//  ServiceManager.swift
//  MarApiApp
//
//  Created by iMac on 03/02/23.
//

import UIKit

class ServiceManager: NSObject {
    
    func getRoversBy(name: String, earthDate: String, withCompletion completion: @escaping (PhotoModel?) -> Void) {

        var request = URLRequest(url: URL(string: "https://api.nasa.gov/mars-photos/api/v1/rovers/\(name.lowercased())/photos?earth_date=2015-6-3&api_key=DD909APndgqoDbH8fdpGuGadGk9KmdJPgO7g6xMl&earth_date=\(earthDate)")!)
        request.httpMethod = "GET"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        let session = URLSession.shared
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            do {
                
                let decoder = JSONDecoder()
                let model = try decoder.decode(PhotoModel.self, from: data!)
                print("\(earthDate) ==> \(model.photos?.count ?? 0)")

                completion(model)
            } catch {
                print("error")
            }
        })

        task.resume()
    }
    
}
