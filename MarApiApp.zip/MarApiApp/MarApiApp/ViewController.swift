//
//  ViewController.swift
//  MarApiApp
//
//  Created by iMac on 02/02/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var primaryPickerView: UIPickerView!
    @IBOutlet weak var datePickerView: UIDatePicker!
    @IBOutlet weak var imageCountLbl: UILabel!
    @IBOutlet weak var idPicker: UIPickerView!
    
    let primaryPickerData = ["Opportunity", "Curiosity", "Spirit"]
    var photoModel: PhotoModel?
    var primarySelectedStr = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        datePickerView.datePickerMode = .date
        datePickerView.preferredDatePickerStyle = .wheels
        
        primaryPickerView.dataSource = self
        primaryPickerView.delegate = self
        idPicker.dataSource = self
        idPicker.delegate = self
        datePickerView.addTarget(self, action: #selector(handleDatePicker), for: .valueChanged)
        datePickerView.maximumDate = Date()
        
        primarySelectedStr = primaryPickerData.first!
        getRoversBy(name: primarySelectedStr)
        imageCountLbl.text = ""

    }
    
    func getRoversBy(name: String) {
        
        let formatter = DateFormatter()
        formatter.calendar = datePickerView.calendar
        formatter.dateFormat = "yyyy-MM-dd"
        let dateString = formatter.string(from: datePickerView.date)

        
        ServiceManager().getRoversBy(name: name, earthDate: dateString) { model in
            self.photoModel = model
            DispatchQueue.main.async {
                self.idPicker.reloadAllComponents()
                
                if let imgSrc = self.photoModel?.photos?.first?.img_src {
                    let url = URL(string:  imgSrc)
                    self.imageView.downloaded(from: url!)
                } else {
                    self.imageView.image = UIImage()
                    self.imageCountLbl.text = "No of Photos: 0"
                }

            }
        }
    }
    
    @objc func handleDatePicker(_ datePicker: UIDatePicker) {
        getRoversBy(name: primarySelectedStr)
    }
}

extension ViewController: UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        1
    }
    
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        if pickerView == primaryPickerView {
            return primaryPickerData.count
        } else {
            return photoModel?.photos?.count ?? 0
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == primaryPickerView {
            return primaryPickerData[row]
        } else {
            let photo = photoModel?.photos?[row]
            imageCountLbl.text = "No of Photos: \(photoModel?.photos?.count ?? 0)"
            return "\(photo?.id ?? 0)"
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == primaryPickerView {
            primarySelectedStr = primaryPickerData[row]
            self.getRoversBy(name: primarySelectedStr)
        } else {
            let photo = photoModel?.photos?[row]
            
            if let imgSrc = photo?.img_src {
                let url = URL(string:  imgSrc)
                self.imageView.downloaded(from: url!)
            }
        }
        
    }
    
}
